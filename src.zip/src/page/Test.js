import React from 'react'

class Test extends React.Component {
    render() {
        return (
            <section className="fantasy-faq section-padding">
                <h1>Welcome</h1>
            </section>
        )
    }
}
export default Test

